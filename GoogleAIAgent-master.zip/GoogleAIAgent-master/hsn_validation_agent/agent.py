from typing import List, Dict, Any
from google.adk.agents import Agent
from .validation import HSNValidator

def validate_hsn_codes(codes: str) -> Dict[str, Any]:
    """
    Validates one or more HSN codes and returns their status and descriptions.
    
    Args:
        codes: A string containing one or more HSN codes separated by spaces or commas
        
    Returns:
        A dictionary with validation results
    """
    # Parse input to extract HSN codes
    import re
    hsn_codes = re.findall(r'\b\d{2}(?:\d{2})?(?:\d{2})?(?:\d{2})?\b', codes)
    
    if not hsn_codes:
        return {
            "status": "error",
            "error_message": "No valid HSN codes found in input. Please provide codes with 2, 4, 6, or 8 digits."
        }
    
    # Validate the codes
    validator = HSNValidator()
    results = validator.validate_codes(hsn_codes)
    
    # Format the response
    response_lines = []
    for res in results:
        if res["is_valid_format"] and res["exists"]:
            msg = f"✅ HSN code {res['input']} is valid: {res['description']}"
        elif not res["is_valid_format"]:
            msg = f"❌ HSN code {res['input']}: {res['error']}"
        else:
            msg = f"❌ HSN code {res['input']}: {res['error']}"
            # Add hierarchy info for advanced feedback
            if res["hierarchy"]:
                hierarchy_feedback = []
                for parent, exists in res["hierarchy"].items():
                    status = "exists" if exists else "missing"
                    hierarchy_feedback.append(f"{parent} ({status})")
                msg += f" | Hierarchy: {', '.join(hierarchy_feedback)}"
        response_lines.append(msg)
    
    return {
        "status": "success",
        "results": "\n".join(response_lines)
    }

# Define the HSN Validation Agent
hsn_validation_agent = Agent(
    name="HSNValidationAgent",
    model="gemini-2.0-flash",  # You can choose an appropriate model
    description="An agent that validates HSN codes based on a master dataset.",
    instruction=(
        "You are an HSN Code Validation Agent. Your job is to validate Harmonized System Nomenclature (HSN) codes. "
        "When a user provides one or more HSN codes (2, 4, 6, or 8 digits), use the validate_hsn_codes tool "
        "to check if they are valid against the master dataset. "
        "Respond with the validation results in a clear, formatted manner."
    ),
    tools=[validate_hsn_codes]
)
