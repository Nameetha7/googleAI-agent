import pandas as pd
import os
from typing import Dict, Optional


# Path to the Excel file (can be set via environment variable or config)
HSN_MASTER_FILE = os.getenv("HSN_MASTER_FILE", "A:\GoogleAgent\hsn_validation_agent\Data\data.csv")

class HSNDataLoader:
    def __init__(self, file_path: str = HSN_MASTER_FILE):
        self.file_path = file_path
        self.hsn_dict = {}  # type: Dict[str, str]
        self.load_data()
    def load_data(self):
        """
        Loads the HSN master data from the Excel file into an in-memory dictionary.
        """
        try:
            df = pd.read_csv(self.file_path, dtype=str)
            df = df[['HSNCode', 'Description']].dropna(subset=['HSNCode'])
            df['HSNCode'] = df['HSNCode'].str.strip()
            df['Description'] = df['Description'].fillna('').str.strip()
            self.hsn_dict = dict(zip(df['HSNCode'], df['Description']))
        except Exception as e:
            print(f"Error loading HSN master data: {e}")
            self.hsn_dict = {}
    def get_description(self, code: str) -> Optional[str]:
        """
        Returns the description for a given HSN code, or None if not found.
        """
        return self.hsn_dict.get(code)
    def code_exists(self, code: str) -> bool:
        """
        Checks if the HSN code exists in the master data.
        """
        return code in self.hsn_dict
    def get_all_codes(self):
        """
        Returns a list of all HSN codes loaded.
        """
        return list(self.hsn_dict.keys())
    def reload_data(self):
        """
        Reloads the HSN master data from the file.
        """
        self.load_data()
    # Should print False if not found
