import re
from typing import List, Dict, Any, Optional
from .data_loader import HSNDataLoader
VALID_HSN_LENGTHS = {2, 4, 6, 8}
class HSNValidator:
    def __init__(self, data_loader: Optional[HSNDataLoader] = None):
        self.data_loader = data_loader or HSNDataLoader()
    def is_valid_format(self, code: str) -> bool:
        """
        Checks if the code is numeric and of valid length.
        """
        return code.isdigit() and len(code) in VALID_HSN_LENGTHS
    def exists_in_master(self, code: str) -> bool:
        """
        Checks if the code exists in the master data.
        """
        return self.data_loader.code_exists(code)
    def get_hierarchy_status(self, code: str) -> Dict[str, bool]:
        """
        For codes longer than 2 digits, checks if parent codes exist.
        Returns a dict: {parent_code: exists_bool}
        """
        hierarchy = {}
        for length in sorted(VALID_HSN_LENGTHS):
            if length < len(code):
                parent = code[:length]
                hierarchy[parent] = self.data_loader.code_exists(parent)
        return hierarchy
    def validate_code(self, code: str) -> Dict[str, Any]:
        """
        Validates a single HSN code.
        Returns a dict with validation results.
        """
        result = {
            "input": code,
            "is_valid_format": self.is_valid_format(code),
            "exists": False,
            "description": None,
            "error": None,
            "hierarchy": None
        }
        if not result["is_valid_format"]:
            result["error"] = "Invalid format: HSN code must be numeric and 2, 4, 6, or 8 digits long."
            return result

        if not self.exists_in_master(code):
            result["error"] = "HSN code not found in master data."
            # Optional: Add hierarchy check even for invalid codes
            result["hierarchy"] = self.get_hierarchy_status(code)
            return result

        result["exists"] = True
        result["description"] = self.data_loader.get_description(code)
        result["hierarchy"] = self.get_hierarchy_status(code)
        return result
    def validate_codes(self, codes: List[str]) -> List[Dict[str, Any]]:
        """
        Validates a list of HSN codes.
        """
        return [self.validate_code(code.strip()) for code in codes if code.strip()]
# validation.py

if __name__ == "__main__":
    validator = HSNValidator()
    codes = ["01", "0101", "01011010", "12345678", "ABC"]
    results = validator.validate_codes(codes)
    for res in results:
        print(res)
