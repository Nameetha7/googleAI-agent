import os
from dotenv import load_dotenv
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from hsn_validation_agent.agent import hsn_validation_agent
import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel
import asyncio

# Load environment variables from .env file
load_dotenv()

# Create a FastAPI app
app = FastAPI(title="HSN Validation Agent")

# HTML for a simple web interface
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>HSN Code Validator</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
        h1 { color: #333; }
        .input-area { margin: 20px 0; }
        textarea { width: 100%; height: 100px; padding: 10px; }
        button { background: #4285f4; color: white; border: none; padding: 10px 20px; cursor: pointer; }
        .result { white-space: pre-wrap; background: #f5f5f5; padding: 15px; margin-top: 20px; }
        .valid { color: green; }
        .invalid { color: red; }
    </style>
</head>
<body>
    <h1>HSN Code Validator</h1>
    <div class="input-area">
        <p>Enter one or more HSN codes (2, 4, 6, or 8 digits) to validate:</p>
        <textarea id="hsn-input" placeholder="Example: 01 0101 01011010"></textarea>
        <button id="validate-btn">Validate</button>
    </div>
    <div id="result" class="result"></div>

    <script>
        document.getElementById('validate-btn').addEventListener('click', async () => {
            const input = document.getElementById('hsn-input').value;
            const resultDiv = document.getElementById('result');
            
            resultDiv.innerHTML = 'Processing...';
            
            try {
                const response = await fetch('/validate', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ input })
                });
                
                const data = await response.json();
                
                if (data.error) {
                    resultDiv.innerHTML = `<span class="invalid">Error: ${data.error}</span>`;
                } else {
                    resultDiv.innerHTML = data.response.replace(/✅/g, '<span class="valid">✅</span>')
                                                      .replace(/❌/g, '<span class="invalid">❌</span>');
                }
            } catch (error) {
                resultDiv.innerHTML = `<span class="invalid">Error: ${error.message}</span>`;
            }
        });
    </script>
</body>
</html>
"""

class ValidationRequest(BaseModel):
    input: str

@app.get("/", response_class=HTMLResponse)
async def get_index():
    return HTML_TEMPLATE

@app.post("/validate")
async def validate_hsn(request: ValidationRequest):
    # Create session service
    session_service = InMemorySessionService()
    
    # Create runner
    runner = Runner(
        agent=hsn_validation_agent,
        app_name="hsn_validation_app",
        session_service=session_service
    )
    
    # Create a unique session ID for this request
    import uuid
    user_id = "web_user"
    session_id = str(uuid.uuid4())
    
    # Create session
    session_service.create_session(
        app_name="hsn_validation_app",
        user_id=user_id,
        session_id=session_id
    )
    
    # Create content from user input
    from google.genai import types
    content = types.Content(
        role="user",
        parts=[types.Part(text=f"Validate HSN codes: {request.input}")]
    )
    
    # Process the request
    response_text = ""
    try:
        events = runner.run(
            user_id=user_id,
            session_id=session_id,
            new_message=content
        )
        
        for event in events:
            if event.is_final_response():
                response_text = event.content.parts[0].text
                break
    except Exception as e:
        return JSONResponse({"error": str(e)})
    
    return JSONResponse({"response": response_text})

def main():
    print("Starting HSN Validation Agent Web Server...")
    # Run FastAPI with Uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)

if __name__ == "__main__":
    main()
